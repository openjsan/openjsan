#line 1 "inc/SQL/Translator/Schema/Graph/Port.pm - /Library/Perl/5.8.6/SQL/Translator/Schema/Graph/Port.pm"
package SQL::Translator::Schema::Graph::Port;

use strict;

1;
