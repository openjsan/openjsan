#line 1 "inc/URI/nntp.pm - /System/Library/Perl/Extras/5.8.6/URI/nntp.pm"
package URI::nntp;  # draft-gilman-news-url-01

require URI::news;
@ISA=qw(URI::news);

1;
