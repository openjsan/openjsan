#line 1 "inc/URI/sips.pm - /System/Library/Perl/Extras/5.8.6/URI/sips.pm"
package URI::sips;
require URI::sip;
@ISA=qw(URI::sip);

sub default_port { 5061 }

1;
