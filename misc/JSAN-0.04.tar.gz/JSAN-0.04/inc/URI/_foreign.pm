#line 1 "inc/URI/_foreign.pm - /System/Library/Perl/Extras/5.8.6/URI/_foreign.pm"
package URI::_foreign;

require URI::_generic;
@ISA=qw(URI::_generic);

1;
