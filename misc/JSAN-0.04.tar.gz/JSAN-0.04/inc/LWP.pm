#line 1 "inc/LWP.pm - /Library/Perl/5.8.6/LWP.pm"
#
# $Id: LWP.pm,v 1.146 2004/12/11 15:41:44 gisle Exp $

package LWP;

$VERSION = "5.803";
sub Version { $VERSION; }

require 5.005;
require LWP::UserAgent;  # this should load everything you need

1;

__END__

#line 658
